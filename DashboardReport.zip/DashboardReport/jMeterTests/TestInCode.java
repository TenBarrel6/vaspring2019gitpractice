package com.cybertek.jMeterTests;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.jmeter.config.Arguments;
import org.apache.jmeter.config.gui.ArgumentsPanel;
import org.apache.jmeter.control.LoopController;
import org.apache.jmeter.control.gui.LoopControlPanel;
import org.apache.jmeter.control.gui.TestPlanGui;
import org.apache.jmeter.engine.StandardJMeterEngine;
import org.apache.jmeter.gui.action.HtmlReportGenerator;
import org.apache.jmeter.protocol.http.control.gui.HttpTestSampleGui;
import org.apache.jmeter.protocol.http.sampler.HTTPSamplerProxy;
import org.apache.jmeter.protocol.java.control.gui.JavaTestSamplerGui;
import org.apache.jmeter.protocol.java.sampler.JavaSampler;
import org.apache.jmeter.report.dashboard.ReportGenerator;
import org.apache.jmeter.reporters.ResultCollector;
import org.apache.jmeter.reporters.Summariser;
import org.apache.jmeter.save.SaveService;
import org.apache.jmeter.testelement.TestElement;
import org.apache.jmeter.testelement.TestPlan;
import org.apache.jmeter.threads.SetupThreadGroup;
import org.apache.jmeter.threads.gui.ThreadGroupGui;
import org.apache.jmeter.util.JMeterUtils;
import org.apache.jorphan.collections.HashTree;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.io.File;
import java.io.FileOutputStream;

import static org.apache.jmeter.JMeter.JMETER_REPORT_OUTPUT_DIR_PROPERTY;

public class TestInCode {
    public static void main(String[] argv) throws Exception {

        String jmeterHome1 = "C:\\apache-jmeter-5.2.1";
        File jmeterHome=new File(jmeterHome1);
//          JMeterUtils.setJMeterHome(jmeterHome);
        String slash = System.getProperty("file.separator");

        if (jmeterHome.exists()) {
            File jmeterProperties = new File(jmeterHome.getPath() + slash + "bin" + slash + "jmeter.properties");
            if (jmeterProperties.exists()) {
                //JMeter Engine
                StandardJMeterEngine jmeter = new StandardJMeterEngine();

                //JMeter initialization (properties, log levels, locale, etc)
                JMeterUtils.setJMeterHome(jmeterHome.getPath());
                JMeterUtils.loadJMeterProperties(jmeterProperties.getPath());
                JMeterUtils.initLogging();// you can comment this line out to see extra log messages of i.e. DEBUG level
                JMeterUtils.initLocale();

                // JMeter Test Plan, basically JOrphan HashTree
                HashTree testPlanTree = new HashTree();

                // Simple Java Request
                JavaSampler javaSampler = new JavaSampler();
                javaSampler.setName("Java Request");
//                javaSampler.setClassname("org.apache.jmeter.protocol.java.test.SleepTest");
                javaSampler.setClassname("com.cybertek.jMeterTests.JavaRequest");
//                Arguments arguments = new Arguments();
//                arguments.addArgument("SleepTime", "1000");
//                arguments.addArgument("SleepMask", "0x33F");
//                javaSampler.setArguments(arguments);
                javaSampler.setProperty(TestElement.TEST_CLASS, JavaSampler.class.getName());
                javaSampler.setProperty(TestElement.GUI_CLASS, JavaTestSamplerGui.class.getName());

                // First HTTP Sampler - open example.com
                HTTPSamplerProxy examplecomSampler = new HTTPSamplerProxy();
                examplecomSampler.setDomain("www.google.com");
                examplecomSampler.setPort(80);
                examplecomSampler.setPath("/");
                examplecomSampler.setMethod("GET");
                examplecomSampler.setName("Open example.com");
                examplecomSampler.setProperty(TestElement.TEST_CLASS, HTTPSamplerProxy.class.getName());
                examplecomSampler.setProperty(TestElement.GUI_CLASS, HttpTestSampleGui.class.getName());


                // Second HTTP Sampler - open acr.org
                HTTPSamplerProxy acrSampler = new HTTPSamplerProxy();
                acrSampler.setDomain("www.acr.org");
                acrSampler.setPort(80);
                acrSampler.setPath("/");
                acrSampler.setMethod("GET");
                acrSampler.setName("Open acr.org");
                acrSampler.setProperty(TestElement.TEST_CLASS, HTTPSamplerProxy.class.getName());
                acrSampler.setProperty(TestElement.GUI_CLASS, HttpTestSampleGui.class.getName());


                // Second HTTP Sampler - open acredit
                HTTPSamplerProxy acreditSampler = new HTTPSamplerProxy();
                acreditSampler.setDomain("acredit.acr.org");
                acreditSampler.setPort(80);
                acreditSampler.setPath("/");
                acreditSampler.setMethod("GET");
                acreditSampler.setName("Open acredit.acr.org");
                acreditSampler.setProperty(TestElement.TEST_CLASS, HTTPSamplerProxy.class.getName());
                acreditSampler.setProperty(TestElement.GUI_CLASS, HttpTestSampleGui.class.getName());


                // Loop Controller
                LoopController loopController = new LoopController();
                loopController.setLoops(3);
                loopController.setFirst(true);
                loopController.setProperty(TestElement.TEST_CLASS, LoopController.class.getName());
                loopController.setProperty(TestElement.GUI_CLASS, LoopControlPanel.class.getName());
                loopController.initialize();

                // Thread Group
                SetupThreadGroup threadGroup = new SetupThreadGroup();
                threadGroup.setName("Example Thread Group");
                threadGroup.setNumThreads(10);
                threadGroup.setRampUp(1);
                threadGroup.setSamplerController(loopController);
                threadGroup.setProperty(TestElement.TEST_CLASS, ThreadGroup.class.getName());
                threadGroup.setProperty(TestElement.GUI_CLASS, ThreadGroupGui.class.getName());

                // Test Plan
                TestPlan testPlan = new TestPlan("Create JMeter Script From Java Code");
                testPlan.setProperty(TestElement.TEST_CLASS, TestPlan.class.getName());
                testPlan.setProperty(TestElement.GUI_CLASS, TestPlanGui.class.getName());
                testPlan.setUserDefinedVariables((Arguments) new ArgumentsPanel().createTestElement());

                // Construct Test Plan from previously initialized elements
                testPlanTree.add(testPlan);
                HashTree threadGroupHashTree = testPlanTree.add(testPlan, threadGroup);
                threadGroupHashTree.add(acreditSampler);
                threadGroupHashTree.add(examplecomSampler);
                threadGroupHashTree.add(acrSampler);
                threadGroupHashTree.add(javaSampler);

                // save generated test plan to JMeter's .jmx file format
                SaveService.saveTree(testPlanTree, new FileOutputStream(jmeterHome + slash + "example.jmx"));

                //add Summarizer output to get test progress in stdout like:
                // summary =      2 in   1.3s =    1.5/s Avg:   631 Min:   290 Max:   973 Err:     0 (0.00%)
                Summariser summary = null;
                String summariserName = JMeterUtils.getPropDefault("summariser.name", "summary");
                if (summariserName.length() > 0) {
                    summary = new Summariser(summariserName);
                }


                // Store execution results into a .jtl file
                String logFile = jmeterHome + slash + "example.jtl";
                ResultCollector logger = new ResultCollector(summary);
                logger.setFilename(logFile);
                testPlanTree.add(testPlanTree.getArray()[0], logger);

                // Run Test Plan
                jmeter.configure(testPlanTree);
                jmeter.run();

                // Generate HTML report with graphs
                String reportFolder = jmeterHome + "\\DashboardReport";
                JMeterUtils.setProperty(JMETER_REPORT_OUTPUT_DIR_PROPERTY, jmeterHome + "\\DashboardReport");
                ReportGenerator generator = new ReportGenerator(logFile,null);
                generator.generate();

                System.out.println("Test completed. See " + jmeterHome + slash + "example.jtl file for results");
                System.out.println("JMeter .jmx script is available at " + jmeterHome + slash + "example.jmx");
                System.out.println("HTML Report is available at :" + reportFolder);
                System.exit(0);

            }
        }

        System.err.println("jmeter.home property is not set or pointing to incorrect location");
        System.exit(1);


    }
}
