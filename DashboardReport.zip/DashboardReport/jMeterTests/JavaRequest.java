package com.cybertek.jMeterTests;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.jmeter.config.Arguments;
import org.apache.jmeter.protocol.java.sampler.AbstractJavaSamplerClient;
import org.apache.jmeter.protocol.java.sampler.JavaSamplerContext;
import org.apache.jmeter.samplers.SampleResult;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class JavaRequest extends AbstractJavaSamplerClient {

    WebDriver driver;

    @Override
    public void setupTest(JavaSamplerContext context){
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        super.setupTest(context);
    }

//    @Override
//    public Arguments getDefaultParameters() {
//
//    }

    @Override
    public SampleResult runTest(JavaSamplerContext arg0) {

        SampleResult result = new SampleResult();

        boolean success = true;

        result.sampleStart();

        // Write your test code here.
        driver.get("https://www.acr.org/");
        System.out.println(driver.getTitle());
        //


        result.sampleEnd();

        result.setSuccessful(success);

        return result;

    }

    @Override
    public void teardownTest(JavaSamplerContext context){
        driver.quit();
//        String verificationErrorString = verificationErrors.toString();
//        if (!"".equals(verificationErrorString)) {
//            fail(verificationErrorString);
//            System.out.println(verificationErrorString);
//        }
        super.teardownTest(context);
    }
}
